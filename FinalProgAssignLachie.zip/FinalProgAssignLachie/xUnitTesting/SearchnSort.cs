﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static testerrrr.MainWindow;


namespace xUnitTesting
{

    public class Movie
    {
        public string MovieID { get; set; }
        public string Title { get; set; }
        // other properties...
    }

    internal class SearchnSort

        //NOT WORKING//
    {
        //public class BinarySearchTests
        //{
        //    [Fact]
        //    public void BinarySearch_ShouldReturnMovie_WhenMovieExists()
        //    {
        //        // Arrange: Create an array of movies
        //        var movies = new Movie[]
        //        {
        //            new Movie { MovieID = "M002", Title = "Inception" },
        //            new Movie { MovieID = "M001", Title = "The Matrix" },
        //            new Movie { MovieID = "M003", Title = "Interstellar" }
        //        };

        //        // Act: Search for a movie by its ID
        //        var result = MovieService.BinarySearch(movies, "M001");

        //        // Assert: Ensure the correct movie is found
        //        Assert.NotNull(result);
        //        Assert.Equal("M001", result.MovieID);
        //        Assert.Equal("The Matrix", result.Title);
        //    }

        //    [Fact]
        //    public void BinarySearch_ShouldReturnNull_WhenMovieDoesNotExist()
        //    {
        //        // Arrange: Create an array of movies
        //        var movies = new Movie[]
        //        {
        //            new Movie { MovieID = "M002", Title = "Inception" },
        //            new Movie { MovieID = "M001", Title = "The Matrix" },
        //            new Movie { MovieID = "M003", Title = "Interstellar" }
        //        };

        //        // Act: Search for a movie by an ID that doesn't exist
        //        var result = MovieService.BinarySearch(movies, "M999");

        //        // Assert: Ensure null is returned when the movie is not found
        //        Assert.Null(result);
        //    }

        //    [Fact]
        //    public void BinarySearch_ShouldReturnMovie_WhenArrayIsUnsorted()
        //    {
        //        // Arrange: Create an unsorted array of movies
        //        var movies = new Movie[]
        //        {
        //            new Movie { MovieID = "M003", Title = "Interstellar" },
        //            new Movie { MovieID = "M001", Title = "The Matrix" },
        //            new Movie { MovieID = "M002", Title = "Inception" }
        //        };

        //        // Act: Search for a movie by its ID
        //        var result = MovieService.BinarySearch(movies, "M002");

        //        // Assert: Ensure the correct movie is found even though the array was unsorted
        //        Assert.NotNull(result);
        //        Assert.Equal("M002", result.MovieID);
        //        Assert.Equal("Inception", result.Title);
        //    }
        //}

    }
}
