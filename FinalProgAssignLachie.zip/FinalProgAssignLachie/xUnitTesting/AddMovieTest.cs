﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static testerrrr.MainWindow;

namespace xUnitTesting
{
    //TESTING ADDING MOVIES//
    //internal class AddMovieTest
    //{
    //    public class MovieService
    //    {
    //        public (bool Success, string Message, Movie Movie) TryCreateMovie(
    //            string movieid, string title, string director, string genre, string yearText)
    //        {
    //            bool yearParsed = int.TryParse(yearText.Trim(), out int year);

    //            if (string.IsNullOrWhiteSpace(movieid) ||
    //                string.IsNullOrWhiteSpace(title) ||
    //                string.IsNullOrWhiteSpace(director) ||
    //                string.IsNullOrWhiteSpace(genre) ||
    //                !yearParsed)
    //            {
    //                return (false, "Please fill in valid movie information.", null);
    //            }

    //            var movie = new Movie
    //            {
    //                MovieID = movieid,
    //                Title = title,
    //                Director = director,
    //                Genre = genre,
    //                ReleaseYear = year,
    //                Availability = true,
    //                Waitlist = new Queue<string>()
    //            };

    //            return (true, "Movie added successfully.", movie);
    //        }
    //    }

    //    public class MovieServiceTests
    //    {
    //        [Fact]
    //        public void TryCreateMovie_ShouldReturnSuccess_WhenValidInput()
    //        {
    //            // Arrange
    //            var service = new MovieService();

    //            // Act
    //            var result = service.TryCreateMovie("M001", "Inception", "Nolan", "Sci-Fi", "2010");

    //            // Assert
    //            Assert.True(result.Success);
    //            Assert.Equal("Movie added successfully.", result.Message);
    //            Assert.NotNull(result.Movie);
    //            Assert.Equal("M001", result.Movie.MovieID);
    //            Assert.Equal(2010, result.Movie.ReleaseYear);
    //        }

    //        [Theory]
    //        [InlineData("", "Inception", "Nolan", "Sci-Fi", "2010")]
    //        [InlineData("M100", "", "Nolan", "Sci-Fi", "2010")]
    //        [InlineData("M100", "Inception", "", "Sci-Fi", "2010")]
    //        [InlineData("M001", "Inception", "Nolan", "", "2010")]
    //        [InlineData("M001", "Inception", "Nolan", "Sci-Fi", "notayear")]
    //        public void TryCreateMovie_ShouldReturnError_WhenInvalidInput(
    //            string id, string title, string director, string genre, string year)
    //        {
    //            // Arrange
    //            var service = new MovieService();

    //            // Act
    //            var result = service.TryCreateMovie(id, title, director, genre, year);

    //            // Assert
    //            Assert.False(result.Success);
    //            Assert.Equal("Please fill in valid movie information.", result.Message);
    //            Assert.Null(result.Movie);
    //        }
    //    }




   // }
}
