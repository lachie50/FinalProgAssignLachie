﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace xUnitTesting
{

    //public class Movie
    //{
    //    public string MovieID { get; set; }
    //    public string Title { get; set; }
    //    public bool Availability { get; set; }
    //    public string CurrentBorrower { get; set; }
    //    public Queue<string> Waitlist { get; set; } = new Queue<string>();
    //}


    //internal class BorrowReturn
    //{
    //    public class MovieManagementTests
    //    {
    //        // Helper method to create a movie
    //        private Movie CreateMovie(string movieId, string title)
    //        {
    //            return new Movie
    //            {
    //                MovieID = movieId,
    //                Title = title,
    //                Availability = true, // Initially available
    //                CurrentBorrower = null,
    //                Waitlist = new Queue<string>()
    //            };
    //        }

    //        [Fact]
    //        public void BorrowMovie_ShouldMarkMovieAsUnavailable_WhenMovieIsAvailable()
    //        {
    //            // Arrange
    //            var movie = CreateMovie("M001", "Inception");
    //            var userName = "John Doe";

    //            // Act
    //            BorrowMovie(movie, userName);

    //            // Assert
    //            Assert.False(movie.Availability);
    //            Assert.Equal(userName, movie.CurrentBorrower);
    //        }

    //        [Fact]
    //        public void BorrowMovie_ShouldNotChangeMovie_WhenMovieIsAlreadyBorrowed()
    //        {
    //            // Arrange
    //            var movie = CreateMovie("M001", "Inception");
    //            movie.Availability = false; // Movie already borrowed
    //            var userName = "John Doe";

    //            // Act
    //            BorrowMovie(movie, userName);

    //            // Assert
    //            Assert.False(movie.Availability); // Should stay unavailable
    //            Assert.Null(movie.CurrentBorrower); // Should not update borrower since movie is unavailable
    //        }

    //        [Fact]
    //        public void MovieReturn_ShouldMakeMovieAvailable_WhenNoWaitlist()
    //        {
    //            // Arrange
    //            var movie = CreateMovie("M001", "Inception");
    //            movie.Availability = false; // Movie is borrowed
    //            movie.CurrentBorrower = "John Doe";

    //            // Act
    //            MovieReturn(movie);

    //            // Assert
    //            Assert.True(movie.Availability);
    //            Assert.Null(movie.CurrentBorrower);
    //        }

    //        [Fact]
    //        public void MovieReturn_ShouldAssignMovieToNextUser_WhenWaitlistIsNotEmpty()
    //        {
    //            // Arrange
    //            var movie = CreateMovie("M001", "Inception");
    //            movie.Availability = false; // Movie is borrowed
    //            movie.CurrentBorrower = "John Doe";
    //            movie.Waitlist.Enqueue("Jane Doe"); // Adding a user to the waitlist

    //            // Act
    //            MovieReturn(movie);

    //            // Assert
    //            Assert.False(movie.Availability); // Movie is still unavailable
    //            Assert.Equal("Jane Doe", movie.CurrentBorrower); // Next user is assigned
    //        }

    //        [Fact]
    //        public void MovieReturn_ShouldClearWaitlist_WhenMovieIsReturnedAndNoNextUser()
    //        {
    //            // Arrange
    //            var movie = CreateMovie("M001", "Inception");
    //            movie.Availability = false; // Movie is borrowed
    //            movie.CurrentBorrower = "John Doe";

    //            // Act
    //            MovieReturn(movie);

    //            // Assert
    //            Assert.True(movie.Availability); // Movie is now available
    //            Assert.Null(movie.CurrentBorrower); // No current borrower
    //            Assert.Empty(movie.Waitlist); // Waitlist should be empty
    //        }

    //        // Mock BorrowMovie method (used for testing)
    //        private void BorrowMovie(Movie selectedMovie, string userName)
    //        {
    //            if (selectedMovie.Availability)
    //            {
    //                selectedMovie.Availability = false;
    //                selectedMovie.CurrentBorrower = userName;
    //            }
    //        }

    //        // Mock MovieReturn method (used for testing)
    //        private void MovieReturn(Movie selectedMovie)
    //        {
    //            if (selectedMovie.Waitlist.Count == 0)
    //            {
    //                selectedMovie.Availability = true;
    //                selectedMovie.CurrentBorrower = null;
    //            }
    //            else
    //            {
    //                string nextUser = selectedMovie.Waitlist.Dequeue();
    //                selectedMovie.CurrentBorrower = nextUser;
    //                selectedMovie.Availability = false;
    //            }
    //        }
    //    }
    //}
}
